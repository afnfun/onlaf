-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 13, 2012 at 02:10 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `info2`
--

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` char(35) NOT NULL DEFAULT '',
  `CountryCode` char(3) NOT NULL DEFAULT '',
  `District` char(20) NOT NULL DEFAULT '',
  `Population` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4319 ;

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `Code` char(3) NOT NULL DEFAULT '',
  `printable_name` char(52) NOT NULL,
  `Continent` enum('Asia','Europe','North America','Africa','Oceania','Antarctica','South America') NOT NULL DEFAULT 'Asia',
  `Region` char(26) NOT NULL DEFAULT '',
  `SurfaceArea` float(10,2) NOT NULL DEFAULT '0.00',
  `IndepYear` smallint(6) DEFAULT NULL,
  `Population` int(11) NOT NULL DEFAULT '0',
  `LifeExpectancy` float(3,1) DEFAULT NULL,
  `GNP` float(10,2) DEFAULT NULL,
  `GNPOld` float(10,2) DEFAULT NULL,
  `LocalName` char(45) NOT NULL DEFAULT '',
  `GovernmentForm` char(45) NOT NULL DEFAULT '',
  `HeadOfState` char(60) DEFAULT NULL,
  `Capital` int(11) DEFAULT NULL,
  `iso` char(2) NOT NULL,
  PRIMARY KEY (`Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `m001`
--

CREATE TABLE `m001` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `item_description` varchar(1024) NOT NULL,
  `item_code` varchar(16) DEFAULT NULL,
  `item_image` varchar(128) DEFAULT NULL,
  `code_status` varchar(8) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `last_update` datetime NOT NULL,
  `TTL` int(4) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=318 ;

-- --------------------------------------------------------

--
-- Table structure for table `message_board`
--

CREATE TABLE `message_board` (
  `token_buffer_id` int(11) NOT NULL AUTO_INCREMENT,
  `source_user_id` int(16) NOT NULL,
  `destination_user_id` int(16) NOT NULL,
  `destination_email` varchar(35) NOT NULL,
  `code_transfer_time` datetime NOT NULL,
  `code` varchar(16) NOT NULL,
  `code_transfer_confirmation` varchar(8) NOT NULL,
  PRIMARY KEY (`token_buffer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=104 ;

-- --------------------------------------------------------

--
-- Table structure for table `token_codes`
--

CREATE TABLE `token_codes` (
  `token_code_id` int(12) NOT NULL AUTO_INCREMENT,
  `token_code` varchar(12) NOT NULL,
  `tokens` int(11) NOT NULL,
  `usage_date` datetime NOT NULL,
  `user_id` int(12) NOT NULL,
  `status` int(11) NOT NULL,
  `ttl_days` int(4) NOT NULL,
  PRIMARY KEY (`token_code_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(7) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `name` varchar(35) NOT NULL,
  `surename` varchar(20) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `website` varchar(50) NOT NULL,
  `password` varchar(35) NOT NULL,
  `email` varchar(35) NOT NULL,
  `address` varchar(64) NOT NULL,
  `city` varchar(64) NOT NULL,
  `country` varchar(32) NOT NULL,
  `activated` int(1) NOT NULL DEFAULT '0',
  `need_activation` int(1) NOT NULL,
  `confirmation` varchar(35) NOT NULL,
  `reg_date` int(11) NOT NULL,
  `last_login` int(11) NOT NULL DEFAULT '0',
  `group_id` int(2) NOT NULL DEFAULT '1',
  `tokens` int(8) NOT NULL,
  `Transfer` int(11) NOT NULL DEFAULT '1',
  `privacy_flag` int(4) NOT NULL DEFAULT '0',
  `language` varchar(12) NOT NULL,
  `Block_Reg_Code` tinyint(1) NOT NULL,
  `Block_Reg_Code_date` datetime NOT NULL,
  `Block_Add_Credit` tinyint(1) NOT NULL,
  `Block_Add_Credit_date` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=71 ;
